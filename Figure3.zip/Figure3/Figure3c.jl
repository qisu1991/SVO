using Printf
using Statistics
using LinearAlgebra
using DelimitedFiles
using IterativeSolvers
using SparseArrays

rng = MersenneTwister(1234)

# generate BA scale-free network
function ba_scale_free(N::Int64, k::Int64)
    mat_seq = spzeros(Int64, N, N)
    mat = ones(Int64, k+1, k+1)
    mat[diagind(mat)] = zeros(Int64,k+1)
    mat_seq[1:k+1,1:k+1] = mat

    for i = k+2:N
        for j = 1:Int64(k/2)
            choice = findall(iszero, mat_seq[i,:])
            choice = setdiff(choice, i)
            deg_seq = sum(mat_seq, dims = 2)
            deg_seq = deg_seq[:,1]
            toss = rand(1)
            threshold = toss[1]*sum(deg_seq[choice])
            deg_acc = 0.0
            for ll in choice
                deg_acc = deg_acc + deg_seq[ll]
                if deg_acc > threshold
                    mat_seq[i,ll] = 1
                    mat_seq[ll,i] = 1
                    break
                end
            end
        end
    end

    inds = findall(!iszero, mat_seq)
    a = getindex.(inds, 1)
    b = getindex.(inds, 2)
    edge_seq = zeros(Int64, length(b), 3)
    edge_seq[:,1] = a
    edge_seq[:,2] = b
    edge_seq[:,3] = ones(Int64, length(a))

    return edge_seq
end

# generate KRL scale-free network
# Connectivity of Growing Random Networks
function krl_scale_free(N::Int64, k::Int64, gamma::Float64)
    mat_seq = spzeros(Int64, N, N)
    mat = ones(Int64, k+1, k+1)
    mat[diagind(mat)] = zeros(Int64,k+1)
    mat_seq[1:k+1,1:k+1] = mat

    for i = k+2:N
        for j = 1:Int64(k/2)
            choice = findall(iszero, mat_seq[i,1:i-1])
            deg_seq = sum(mat_seq, dims = 2)
            deg_seq = deg_seq[:,1]
            toss = rand(1)
            threshold = toss[1]*sum(deg_seq[choice].^gamma)
            deg_acc = 0.0
            for ll in choice
                deg_acc = deg_acc + deg_seq[ll]^gamma
                if deg_acc > threshold
                    mat_seq[i,ll] = 1
                    mat_seq[ll,i] = 1
                    break
                end
            end
        end
    end

    inds = findall(!iszero, mat_seq)
    a = getindex.(inds, 1)
    b = getindex.(inds, 2)
    edge_seq = zeros(Int64, length(b), 3)
    edge_seq[:,1] = a
    edge_seq[:,2] = b
    edge_seq[:,3] = ones(Int64, length(a))

    return edge_seq
end


N = 100
k = 4
beta = 0.01

# cooperation rates for 1000 BA scale-free network 
for i = 1:1000
        edge_seq = ba_scale_free(N, k)
        G = sparse(edge_seq[:,1], edge_seq[:,2], edge_seq[:,3], N, N)
        deg = sum(G, dims = 2)
        P = spzeros(Float64, N, N)
        P[:,:] = G./deg
        P2 = P^2
        xC = zeros(N,2)
        b = 8
        xC[:,1] = (diag(P2)*sin(pi/4)*b/4 .- cos(pi/4)/4)*beta .+ 1/2
        xC[:,2] = deg

        str_output = string("xC_BA",".txt")
        g = open(str_output,"a")
        writedlm(g, transpose(xC[:,1]))

        close(g)
        str_output = string("xD_BA",".txt")
        g = open(str_output,"a")
        writedlm(g, transpose(xC[:,2]))
        close(g)
end

# cooperation rates for 1000 KRL scale-free networks with gamma=4.0 
for i = 1:1000
        edge_seq = krl_scale_free(N, k, 4.0)
        G = sparse(edge_seq[:,1], edge_seq[:,2], edge_seq[:,3], N, N)
        deg = sum(G, dims = 2)
        P = spzeros(Float64, N, N)
        P[:,:] = G./deg
        P2 = P^2
        xC = zeros(N,2)
        b = 8
        xC[:,1] = (diag(P2)*sin(pi/4)*b/4 .- cos(pi/4)/4)*beta .+ 1/2
        xC[:,2] = deg

        str_output = string("xC_krl4",".txt")
        g = open(str_output,"a")
        writedlm(g, transpose(xC[:,1]))
        close(g)
        str_output = string("xD_krl4",".txt")
        g = open(str_output,"a")
        writedlm(g, transpose(xC[:,2]))
        close(g)
end
