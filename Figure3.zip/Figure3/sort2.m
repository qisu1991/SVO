function [x_list1,y_list1] = sort2(x_list, y_list)
[x_list1,r1] = sort(x_list,'ascend');
y_list1 = y_list(r1);

for i = 1:length(x_list1)
    id = find(x_list1 == x_list1(i));
    [y_list2,~] = sort(y_list1(id),'ascend');
    y_list1(id) = y_list2;
end
end